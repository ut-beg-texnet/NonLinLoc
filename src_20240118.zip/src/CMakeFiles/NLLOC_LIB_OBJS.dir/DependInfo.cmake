
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/Users/anthony/soft/NLLoc/src/GridMemLib.c" "CMakeFiles/NLLOC_LIB_OBJS.dir/GridMemLib.c.o" "gcc" "CMakeFiles/NLLOC_LIB_OBJS.dir/GridMemLib.c.o.d"
  "/Users/anthony/soft/NLLoc/src/NLLocLib.c" "CMakeFiles/NLLOC_LIB_OBJS.dir/NLLocLib.c.o" "gcc" "CMakeFiles/NLLOC_LIB_OBJS.dir/NLLocLib.c.o.d"
  "/Users/anthony/soft/NLLoc/src/calc_crust_corr.c" "CMakeFiles/NLLOC_LIB_OBJS.dir/calc_crust_corr.c.o" "gcc" "CMakeFiles/NLLOC_LIB_OBJS.dir/calc_crust_corr.c.o.d"
  "/Users/anthony/soft/NLLoc/src/loclist.c" "CMakeFiles/NLLOC_LIB_OBJS.dir/loclist.c.o" "gcc" "CMakeFiles/NLLOC_LIB_OBJS.dir/loclist.c.o.d"
  "/Users/anthony/soft/NLLoc/src/otime_limit.c" "CMakeFiles/NLLOC_LIB_OBJS.dir/otime_limit.c.o" "gcc" "CMakeFiles/NLLOC_LIB_OBJS.dir/otime_limit.c.o.d"
  "/Users/anthony/soft/NLLoc/src/phaselist.c" "CMakeFiles/NLLOC_LIB_OBJS.dir/phaselist.c.o" "gcc" "CMakeFiles/NLLOC_LIB_OBJS.dir/phaselist.c.o.d"
  "/Users/anthony/soft/NLLoc/src/velmod.c" "CMakeFiles/NLLOC_LIB_OBJS.dir/velmod.c.o" "gcc" "CMakeFiles/NLLOC_LIB_OBJS.dir/velmod.c.o.d"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
