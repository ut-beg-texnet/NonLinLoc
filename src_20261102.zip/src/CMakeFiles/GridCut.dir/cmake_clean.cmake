file(REMOVE_RECURSE
  "/Users/anthony/bin/GridCut"
  "/Users/anthony/bin/GridCut.pdb"
  "CMakeFiles/GridCut.dir/GridCut.c.o"
  "CMakeFiles/GridCut.dir/GridCut.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/GridCut.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
