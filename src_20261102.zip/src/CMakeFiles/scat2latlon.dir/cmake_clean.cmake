file(REMOVE_RECURSE
  "/Users/anthony/bin/scat2latlon"
  "/Users/anthony/bin/scat2latlon.pdb"
  "CMakeFiles/scat2latlon.dir/scat2latlon.c.o"
  "CMakeFiles/scat2latlon.dir/scat2latlon.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/scat2latlon.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
