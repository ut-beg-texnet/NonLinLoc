file(REMOVE_RECURSE
  "/Users/anthony/bin/NLLoc_func_test"
  "/Users/anthony/bin/NLLoc_func_test.pdb"
  "CMakeFiles/NLLoc_func_test.dir/NLLoc_func_test.c.o"
  "CMakeFiles/NLLoc_func_test.dir/NLLoc_func_test.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/NLLoc_func_test.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
