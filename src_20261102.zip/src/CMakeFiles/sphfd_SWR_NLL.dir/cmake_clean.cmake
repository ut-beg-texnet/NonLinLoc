file(REMOVE_RECURSE
  "/Users/anthony/bin/sphfd_SWR_NLL"
  "/Users/anthony/bin/sphfd_SWR_NLL.pdb"
  "CMakeFiles/sphfd_SWR_NLL.dir/sphfd_SWR_NLL.c.o"
  "CMakeFiles/sphfd_SWR_NLL.dir/sphfd_SWR_NLL.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/sphfd_SWR_NLL.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
