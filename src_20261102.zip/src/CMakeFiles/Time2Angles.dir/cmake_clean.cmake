file(REMOVE_RECURSE
  "/Users/anthony/bin/Time2Angles"
  "/Users/anthony/bin/Time2Angles.pdb"
  "CMakeFiles/Time2Angles.dir/Time2Angles1.c.o"
  "CMakeFiles/Time2Angles.dir/Time2Angles1.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/Time2Angles.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
