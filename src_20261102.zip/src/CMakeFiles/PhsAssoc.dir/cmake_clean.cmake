file(REMOVE_RECURSE
  "/Users/anthony/bin/PhsAssoc"
  "/Users/anthony/bin/PhsAssoc.pdb"
  "CMakeFiles/PhsAssoc.dir/PhsAssoc.c.o"
  "CMakeFiles/PhsAssoc.dir/PhsAssoc.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/PhsAssoc.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
