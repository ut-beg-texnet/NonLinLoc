file(REMOVE_RECURSE
  "/Users/anthony/bin/Vel2Grid3D"
  "/Users/anthony/bin/Vel2Grid3D.pdb"
  "CMakeFiles/Vel2Grid3D.dir/Vel2Grid3D.c.o"
  "CMakeFiles/Vel2Grid3D.dir/Vel2Grid3D.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/Vel2Grid3D.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
