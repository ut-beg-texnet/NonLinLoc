file(REMOVE_RECURSE
  "/Users/anthony/bin/oct2grid"
  "/Users/anthony/bin/oct2grid.pdb"
  "CMakeFiles/oct2grid.dir/oct2grid.c.o"
  "CMakeFiles/oct2grid.dir/oct2grid.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/oct2grid.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
