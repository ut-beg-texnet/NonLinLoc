file(REMOVE_RECURSE
  "/Users/anthony/bin/interface2fmm"
  "/Users/anthony/bin/interface2fmm.pdb"
  "CMakeFiles/interface2fmm.dir/interface2fmm.c.o"
  "CMakeFiles/interface2fmm.dir/interface2fmm.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/interface2fmm.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
