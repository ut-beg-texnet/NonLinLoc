file(REMOVE_RECURSE
  "/Users/anthony/bin/Grid2Time"
  "/Users/anthony/bin/Grid2Time.pdb"
  "CMakeFiles/Grid2Time.dir/Grid2Time1.c.o"
  "CMakeFiles/Grid2Time.dir/Grid2Time1.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/Grid2Time.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
