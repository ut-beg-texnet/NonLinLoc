file(REMOVE_RECURSE
  "/Users/anthony/bin/Loc2ddct"
  "/Users/anthony/bin/Loc2ddct.pdb"
  "CMakeFiles/Loc2ddct.dir/Loc2ddct.c.o"
  "CMakeFiles/Loc2ddct.dir/Loc2ddct.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/Loc2ddct.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
