file(REMOVE_RECURSE
  "/Users/anthony/bin/mag_func_test"
  "/Users/anthony/bin/mag_func_test.pdb"
  "CMakeFiles/mag_func_test.dir/mag_func_test.c.o"
  "CMakeFiles/mag_func_test.dir/mag_func_test.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/mag_func_test.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
