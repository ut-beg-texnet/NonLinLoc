file(REMOVE_RECURSE
  "/Users/anthony/bin/ttime_func_test"
  "/Users/anthony/bin/ttime_func_test.pdb"
  "CMakeFiles/ttime_func_test.dir/ttime_func_test.c.o"
  "CMakeFiles/ttime_func_test.dir/ttime_func_test.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/ttime_func_test.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
