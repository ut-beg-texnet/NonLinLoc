file(REMOVE_RECURSE
  "/Users/anthony/bin/loc_combine"
  "/Users/anthony/bin/loc_combine.pdb"
  "CMakeFiles/loc_combine.dir/loc_combine.c.o"
  "CMakeFiles/loc_combine.dir/loc_combine.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/loc_combine.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
