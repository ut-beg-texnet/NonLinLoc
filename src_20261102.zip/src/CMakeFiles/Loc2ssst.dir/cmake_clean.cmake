file(REMOVE_RECURSE
  "/Users/anthony/bin/Loc2ssst"
  "/Users/anthony/bin/Loc2ssst.pdb"
  "CMakeFiles/Loc2ssst.dir/Loc2ssst.c.o"
  "CMakeFiles/Loc2ssst.dir/Loc2ssst.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/Loc2ssst.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
