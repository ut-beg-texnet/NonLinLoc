file(REMOVE_RECURSE
  "/Users/anthony/bin/grid2scat"
  "/Users/anthony/bin/grid2scat.pdb"
  "CMakeFiles/grid2scat.dir/grid2scat.c.o"
  "CMakeFiles/grid2scat.dir/grid2scat.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/grid2scat.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
