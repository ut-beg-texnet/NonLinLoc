file(REMOVE_RECURSE
  "/Users/anthony/bin/Vel2Grid"
  "/Users/anthony/bin/Vel2Grid.pdb"
  "CMakeFiles/Vel2Grid.dir/Vel2Grid1.c.o"
  "CMakeFiles/Vel2Grid.dir/Vel2Grid1.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/Vel2Grid.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
