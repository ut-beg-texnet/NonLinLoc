file(REMOVE_RECURSE
  "/Users/anthony/bin/NLLoc"
  "/Users/anthony/bin/NLLoc.pdb"
  "CMakeFiles/NLLoc.dir/NLLoc_main.c.o"
  "CMakeFiles/NLLoc.dir/NLLoc_main.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/NLLoc.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
