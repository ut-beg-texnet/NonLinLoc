file(REMOVE_RECURSE
  "/Users/anthony/bin/LocSum"
  "/Users/anthony/bin/LocSum.pdb"
  "CMakeFiles/LocSum.dir/LocSum.c.o"
  "CMakeFiles/LocSum.dir/LocSum.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/LocSum.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
