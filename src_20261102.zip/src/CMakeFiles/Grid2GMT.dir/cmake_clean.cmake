file(REMOVE_RECURSE
  "/Users/anthony/bin/Grid2GMT"
  "/Users/anthony/bin/Grid2GMT.pdb"
  "CMakeFiles/Grid2GMT.dir/Grid2GMT.c.o"
  "CMakeFiles/Grid2GMT.dir/Grid2GMT.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/Grid2GMT.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
