file(REMOVE_RECURSE
  "/Users/anthony/bin/fpfit2hyp"
  "/Users/anthony/bin/fpfit2hyp.pdb"
  "CMakeFiles/fpfit2hyp.dir/fpfit2hyp.c.o"
  "CMakeFiles/fpfit2hyp.dir/fpfit2hyp.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/fpfit2hyp.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
