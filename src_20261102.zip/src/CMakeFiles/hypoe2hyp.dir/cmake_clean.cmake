file(REMOVE_RECURSE
  "/Users/anthony/bin/hypoe2hyp"
  "/Users/anthony/bin/hypoe2hyp.pdb"
  "CMakeFiles/hypoe2hyp.dir/hypoe2hyp.c.o"
  "CMakeFiles/hypoe2hyp.dir/hypoe2hyp.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/hypoe2hyp.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
