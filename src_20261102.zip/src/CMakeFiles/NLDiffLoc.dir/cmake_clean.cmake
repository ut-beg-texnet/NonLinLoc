file(REMOVE_RECURSE
  "/Users/anthony/bin/NLDiffLoc"
  "/Users/anthony/bin/NLDiffLoc.pdb"
  "CMakeFiles/NLDiffLoc.dir/NLDiffLoc.c.o"
  "CMakeFiles/NLDiffLoc.dir/NLDiffLoc.c.o.d"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/NLDiffLoc.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
