struct vhead {
char	header[144];
double	clat, clon, cz;
double  fxs, fys, fzs;
double	x0, y0, z0, dx, dy, dz;
float	az;
int	nx, ny, nz;
};

#include "GridLib.h"
