double calc_crust_corr (char ps, double lat, double lon, double depth, double elev, double dtdd );

