long int juliam();
long int juliam_KP();  
void datum();
void datum_KP();
short int juliad();
void juliadtodate();
int GseBrowse();
void ReadGseHeader();
char *Comp6toBuf();
void Decomp6toArray();
void MakeDiff();
void RemoveDiff();
int ReadGseFromMemory();
int i2gets();
int i4gets();
int FreeMasterHeader();
int remove_leading();


station_struct *GetStationList();
cal_struct *ReadSedCalPath();
void ReadSedPaz();
cal_struct *ReadStnDef();
cal_struct *ReadCalFromFile();
cal_struct *AssignCalInfo();
cal_struct *FreeCalInfo();
station_struct *ReadStnInfo();
